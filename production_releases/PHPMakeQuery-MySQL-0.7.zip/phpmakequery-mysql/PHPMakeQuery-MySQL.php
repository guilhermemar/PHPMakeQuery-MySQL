<?php
/*
 * include das classes do projeto
 */
require_once "src/MQuery.php";
require_once "src/MQException.php";
require_once "src/MQField.php";
require_once "src/MQFunctions.php";
require_once "src/MQJoin.php";
require_once "src/MQOrderBy.php";
require_once "src/MQSelect.php";
require_once "src/MQSubSelect.php";
require_once "src/MQValue.php";
require_once "src/MQWhere.php";
require_once "src/MQWhereGroup.php";
?>